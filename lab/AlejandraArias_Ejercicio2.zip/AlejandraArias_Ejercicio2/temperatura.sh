wget http://openmv.net/file/room-temperature.csv

python pca_room.py

rm room-temperature.csv
